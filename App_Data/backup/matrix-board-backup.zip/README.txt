Matrix board nightly backup
Created by legacy maintenance worker.
Restore target: staging only.
